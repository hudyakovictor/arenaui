import Phaser from 'phaser';
import { ArenaEncounterScene, UiGalleryScene, AcademyPathScene, CollectionScene, EXAMPLE_TASK } from './uiKernel';
const game = new Phaser.Game({
  type: Phaser.AUTO, parent: 'game', backgroundColor: '#070B14',
  width: 390, height: 844,
  scene: [ArenaEncounterScene, UiGalleryScene, AcademyPathScene, CollectionScene],
  scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH }
});
game.scene.start('ArenaEncounter', { task: EXAMPLE_TASK });
