# Signal Arena UI Kernel

Phaser 3 + TypeScript starter prototype for Signal Arena.

## Run

```bash
npm install
npm run dev
```

## Included pages/scenes

- `ArenaEncounter` — core game encounter with mandatory browser widget, skill cards, 4 answers, hidden enemy and feedback.
- `AcademyPath` — first Academy path placeholder.
- `Collection` — skill/trophy collection placeholder.
- `UiGallery` — visual states gallery.

## Rules built into code

- Arena tasks require 1–7 source tabs, an active source, cards and exactly four answers.
- Daily warm-up is `ArenaMode`, not a navigation item.
- Bottom navigation excludes a separate warm-up screen.
- Desktop/mobile use the same scene and game loop; only positioning adapts.
- UI tokens are centralized in `SA`.

This is a starter kernel, not the full game. Add assets, backend contracts, real Chart/News panels, Academy lesson content and Phaser UI components incrementally.
