# Signal Arena — Phaser 4.2.1 Skeleton

## Structure
```
phaser/
├── package.json          # Phaser 4.2.1 + Vite + TypeScript
├── vite.config.ts        # Vite config (mobile, PWA-ready)
├── tsconfig.json         # TypeScript strict
├── index.html            # Entry point
└── src/
    ├── main.ts           # Game bootstrap
    ├── config/
    │   ├── gameConfig.ts  # Phaser config (390×844, FIT scale)
    │   └── balanceConfig.ts # XP, coins, cooldowns, mastery
    ├── scenes/
    │   ├── BootScene.ts   # Asset loading + state init
    │   ├── ArenaScene.ts  # Full Arena: TopBar → Question → Threat → Browser → Skills → Answers → Reveal → BottomNav
    │   ├── AcademyScene.ts # Chapter path with lesson nodes + CTA
    │   └── CollectionScene.ts # Card grid 3×3 with tap interaction
    └── types/
        └── index.ts      # SkillCard, Enemy, Encounter, AnswerOption types
```

## Run
```bash
cd phaser && npm install && npm run dev
```

## Terminal Design System tokens
All colors match `design-system.tokens.json`:
- bg #070B14, surface #0C1323, elevated #111B2E, cyan #31D6C4, good #3BDE8A, bad #FF596D
- Inter (UI) + IBM Plex Mono (data)
- 390×844 mobile-first, Scale.FIT
