export const balanceConfig = {
  xp: {
    perCorrectAnswer: 12,
    perChapterExam: 50,
    perDailyWarmup: 8,
    levelThresholds: [0, 100, 250, 500, 1000, 1800, 3000, 4800, 7200, 10000]
  },
  coins: { perCorrectAnswer: 3, perChapterExam: 15, perDailyWarmup: 2 },
  cooldowns: { dailyWarmup: 0, chapterExamRetry: 0, fixMissionRetry: 0 },
  attempts: { maxPerEncounter: 1, maxPerChapterExam: 1, fixMissionScenarios: 3 },
  mastery: { minCorrectRatio: 0.7, minEncounters: 3 }
};
