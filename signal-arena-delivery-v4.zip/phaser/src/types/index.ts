export type SkillDomain = 'technical' | 'risk' | 'context' | 'crypto' | 'human' | 'cognitive';
export interface SkillCard { id: string; name: string; domain: SkillDomain; icon: string; mastered: boolean; locked: boolean; }
export interface Enemy { id: string; name: string; family: string; isMVP: boolean; stage: 'silhouette' | 'revealed' | 'defeated'; }
export interface AnswerOption { label: string; text: string; isWait?: boolean; }
export interface Encounter { id: string; chapterId: string; question: string; sources: string[]; skills: string[]; answers: AnswerOption[]; correctAnswer: number; enemyId: string; }
export type ScreenKey = 'arena' | 'academy-path' | 'academy-lesson' | 'collection' | 'more' | 'error-journal' | 'onboarding' | 'store' | 'settings' | 'mastery-check' | 'daily-warmup' | 'tournament';
