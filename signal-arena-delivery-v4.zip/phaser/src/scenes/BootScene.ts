import Phaser from 'phaser';
export class BootScene extends Phaser.Scene {
  constructor() { super({ key: 'BootScene' }); }
  preload(): void {
    // Assets loaded here in production
  }
  create(): void {
    this.registry.set('level', 4);
    this.registry.set('xp', 680);
    this.registry.set('xpMax', 1000);
    this.registry.set('coins', 1240);
    this.scene.start('ArenaScene');
  }
}
