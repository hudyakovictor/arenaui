import Phaser from 'phaser';
export class CollectionScene extends Phaser.Scene {
  constructor() { super({ key: 'CollectionScene' }); }
  create(): void {
    this.cameras.main.setBackgroundColor(0x070B14);
    this.add.text(14, 14, 'Коллекция', { fontFamily: 'Inter, sans-serif', fontSize: '22px', color: '#E9F2FF' });
    this.add.text(14, 42, '6 КАРТ · 2 ТРОФЕЯ', { fontFamily: 'IBM Plex Mono, monospace', fontSize: '12px', color: '#62708A' });
    const cards = [
      { n: 'ТРЕНД', s: 'mastered' }, { n: 'ОБЪЁМ', s: 'mastered' }, { n: 'РИСК', s: 'mastered' },
      { n: 'ЖДАТЬ', s: 'available' }, { n: 'НОВОСТИ', s: 'available' }, { n: 'СТАКАН', s: 'available' },
      { n: '?', s: 'locked' }, { n: '?', s: 'locked' }, { n: '?', s: 'locked' }
    ];
    cards.forEach((c, i) => {
      const cx = 14 + (i % 3) * 120, cy = 80 + Math.floor(i / 3) * 120;
      const col = c.s === 'mastered' ? 0x3BDE8A : c.s === 'available' ? 0x31D6C4 : 0x62708A;
      this.add.rectangle(cx, cy, 110, 110, 0x0C1323).setStrokeStyle(1, c.s === 'locked' ? 0x22304A : col).setOrigin(0)
        .setInteractive().on('pointerdown', () => {
          if (c.s !== 'locked') {
            const t = this.add.text(195, 400, c.n, { fontFamily: 'Inter, sans-serif', fontSize: '24px', color: '#E9F2FF' }).setOrigin(0.5);
            this.time.delayedCall(1000, () => t.destroy());
          }
        });
      this.add.text(cx + 55, cy + 55, c.n, { fontFamily: 'IBM Plex Mono, monospace', fontSize: '10px', color: `#${col.toString(16).padStart(6, '0')}` }).setOrigin(0.5);
    });
  }
}
