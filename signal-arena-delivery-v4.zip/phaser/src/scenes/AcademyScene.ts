import Phaser from 'phaser';
export class AcademyScene extends Phaser.Scene {
  constructor() { super({ key: 'AcademyScene' }); }
  create(): void {
    this.cameras.main.setBackgroundColor(0x070B14);
    this.add.text(14, 14, 'Академия', { fontFamily: 'Inter, system-ui, sans-serif', fontSize: '22px', color: '#E9F2FF' });
    this.add.text(14, 42, 'ГЛАВА 1 · ОСНОВЫ РЫНКА · 2 / 5', { fontFamily: 'IBM Plex Mono, monospace', fontSize: '12px', color: '#62708A' });
    const lessons = [
      { name: 'Что такое тренд', status: 'done', meta: '3 блока · карта «Тренд»' },
      { name: 'Объём и подтверждение', status: 'done', meta: '4 блока · карта «Объём»' },
      { name: 'Ложный пробой', status: 'current', meta: '4 блока · Fake Breakout Phantom' },
      { name: 'Управление риском', status: 'locked', meta: 'Откроется после урока 3' },
      { name: 'Экзамен главы', status: 'locked', meta: 'Нужно 4 / 5 уроков' }
    ];
    lessons.forEach((l, i) => {
      const ly = 80 + i * 58;
      const c = l.status === 'done' ? 0x3BDE8A : l.status === 'current' ? 0x31D6C4 : 0x62708A;
      this.add.circle(34, ly + 20, 20, 0x0C1323).setStrokeStyle(1, c);
      this.add.text(34, ly + 20, l.status === 'done' ? '✓' : String(i + 1).padStart(2, '0'), { fontFamily: 'IBM Plex Mono, monospace', fontSize: '10px', color: `#${c.toString(16).padStart(6, '0')}` }).setOrigin(0.5);
      this.add.text(64, ly + 12, l.name, { fontFamily: 'Inter, sans-serif', fontSize: '13px', color: '#E9F2FF' });
      this.add.text(64, ly + 30, l.meta, { fontFamily: 'IBM Plex Mono, monospace', fontSize: '9px', color: '#62708A' });
    });
    this.add.text(14, 700, 'Ложный пробой · ~6 мин', { fontFamily: 'IBM Plex Mono, monospace', fontSize: '11px', color: '#93A3BC' });
    this.add.rectangle(14, 720, 362, 44, 0x31D6C4).setOrigin(0).setInteractive()
      .on('pointerdown', () => this.scene.start('ArenaScene'));
    this.add.text(195, 742, 'Продолжить урок', { fontFamily: 'Inter, sans-serif', fontSize: '13px', color: '#03110f' }).setOrigin(0.5);
  }
}
