import Phaser from 'phaser';
const COLORS = {
  bg: 0x070B14, surface: 0x0C1323, elevated: 0x111B2E, hover: 0x14223A,
  border: 0x22304A, strong: 0x344563, cyan: 0x31D6C4, good: 0x3BDE8A,
  bad: 0xFF596D, warn: 0xFFB341, paper: 0xE7DFD0, ink: 0x1C1916, crypto: 0xB783FF,
  text: 0xE9F2FF, sub: 0x93A3BC, muted: 0x62708A
};
const FONT_UI = { fontFamily: 'Inter, system-ui, sans-serif' };
const FONT_MONO = { fontFamily: 'IBM Plex Mono, Consolas, monospace' };
export class ArenaScene extends Phaser.Scene {
  private selectedSkill = 1;
  constructor() { super({ key: 'ArenaScene' }); }
  create(): void {
 this.cameras.main.setBackgroundColor(COLORS.bg);
    this.createTopBar();
    this.createStrip();
    this.createQuestion();
    this.createThreat();
    this.createBrowser();
    this.createSkills();
    this.createAnswers();
    this.createBottomNav();
  }
  private createTopBar(): void {
    this.add.rectangle(0, 0, 390, 56, COLORS.elevated).setOrigin(0).setStrokeStyle(1, COLORS.border);
    this.add.circle(17, 28, 17, COLORS.surface).setStrokeStyle(1, COLORS.cyan);
    this.add.text(17, 28, 'L4', { ...FONT_MONO, fontSize: '11px', color: '#31D6C4' }).setOrigin(0.5);
    this.add.text(50, 14, 'УРОВЕНЬ 4', { ...FONT_MONO, fontSize: '9px', color: '#62708A' });
    this.add.text(50, 26, '680 / 1000', { ...FONT_MONO, fontSize: '9px', color: '#62708A' });
    this.add.rectangle(50, 38, 200, 4, COLORS.inset || 0x060A12).setStrokeStyle(1, COLORS.border).setOrigin(0, 0.5);
    this.add.rectangle(50, 38, 136, 4, COLORS.cyan).setOrigin(0, 0.5);
    this.add.text(260, 28, '◉ 1240', { ...FONT_MONO, fontSize: '11px', color: '#93A3BC' });
  }
  private createStrip(): void {
    this.add.text(14, 62, 'ГЛ.1 · УР.3', { ...FONT_MONO, fontSize: '9px', color: '#31D6C4' });
    this.add.text(80, 62, '2 / 4', { ...FONT_MONO, fontSize: '9px', color: '#62708A' });
    this.add.text(330, 62, '⏱ Без лимита', { ...FONT_MONO, fontSize: '9px', color: '#62708A' });
  }
  private createQuestion(): void {
    this.add.rectangle(14, 76, 362, 44, COLORS.paper).setOrigin(0).setStrokeStyle(4, COLORS.cyan, 1);
    this.add.text(28, 80, 'СИТУАЦИЯ · ENCOUNTER 04', { ...FONT_MONO, fontSize: '9px', color: 'rgba(28,25,22,0.5)' });
    this.add.text(28, 92, 'Цена пробила уровень. Объём отказывается.', { fontSize: '13px', color: '#1C1916', ...FONT_UI });
  }
  private createThreat(): void {
    this.add.rectangle(14, 122, 362, 30, COLORS.surface).setStrokeStyle(1, COLORS.strong, Phaser.Physics.Arcade.STROKE_DASHED).setOrigin(0);
    this.add.circle(28, 137, 14, COLORS.surface).setStrokeStyle(1, COLORS.strong);
    this.add.text(28, 137, '?', { ...FONT_MONO, fontSize: '15px', color: '#31D6C4' }).setOrigin(0.5);
    this.add.text(50, 130, 'UNKNOWN THREAT', { ...FONT_MONO, fontSize: '10px', color: '#93A3BC' });
    this.add.text(50, 140, 'Враг раскроется после решения', { ...FONT_MONO, fontSize: '9px', color: '#62708A' });
  }
  private createBrowser(): void {
    const bx = 14, by = 156, bw = 362;
    this.add.rectangle(bx, by, bw, 190, 0x060A12).setStrokeStyle(1, COLORS.strong).setOrigin(0);
    this.add.rectangle(bx, by, bw, 30, COLORS.elevated).setOrigin(0).setStrokeStyle(1, COLORS.border);
    this.add.text(bx + 10, by + 10, '● ● ●', { fontSize: '5px', color: '#62708A' });
    this.add.text(bx + 50, by + 10, 'arena://sandbox/encounter-04', { ...FONT_MONO, fontSize: '8px', color: '#62708A' });
    const tabs = ['▥ CHART', '▤ NEWS', '≋ BOOK', '◇'];
    tabs.forEach((tab, i) => {
      const tx = bx + i * (bw / 4);
      this.add.rectangle(tx, by + 30, bw / 4, 36, i === 0 ? COLORS.hover : COLORS.surface).setStrokeStyle(1, COLORS.border).setOrigin(0);
      this.add.text(tx + bw / 8, by + 48, tab, { ...FONT_MONO, fontSize: '9px', color: i === 0 ? '#31D6C4' : '#62708A' }).setOrigin(0.5);
    });
    this.add.text(bx + 10, by + 74, 'BTC/USDT · 15M', { ...FONT_MONO, fontSize: '8px', color: '#62708A' });
    this.add.text(bx + bw - 80, by + 74, 'VOL 2.1K', { ...FONT_MONO, fontSize: '8px', color: '#62708A' });
  }
  private createSkills(): void {
    const skills = [
      { name: 'ТРЕНД', icon: '↗', mastered: false, locked: false },
      { name: 'ОБЪЁМ', icon: '▥', mastered: false, locked: false },
      { name: 'РИСК', icon: '◈', mastered: true, locked: false },
      { name: 'ЖДАТЬ', icon: '◷', mastered: false, locked: true }
    ];
    const cardW = (362 - 18) / 4;
    skills.forEach((s, i) => {
      const sx = 14 + i * (cardW + 6), sy = 354;
      const bg = i === this.selectedSkill ? COLORS.hover : COLORS.surface;
      this.add.rectangle(sx, sy, cardW, 58, bg).setStrokeStyle(i === this.selectedSkill ? 2 : 1, i === this.selectedSkill ? COLORS.cyan : COLORS.border).setOrigin(0)
        .setInteractive().on('pointerdown', () => { if (!s.locked) { this.selectedSkill = i; this.scene.restart(); } });
      this.add.text(sx + cardW / 2, sy + 16, s.icon, { fontSize: '14px', color: s.mastered ? '#3BDE8A' : '#31D6C4' }).setOrigin(0.5);
      this.add.text(sx + cardW / 2, sy + 40, s.name, { ...FONT_MONO, fontSize: '8px', color: s.locked ? '#62708A' : '#93A3BC' }).setOrigin(0.5);
    });
  }
  private createAnswers(): void {
    const answers = [
      { l: 'A', t: 'Войти сразу — движение уже началось' },
      { l: 'B', t: 'Подождать ретест и подтверждение объёмом' },
      { l: 'C', t: 'Снизить риск, проверить старшие таймфреймы' },
      { l: 'D', t: 'Увеличить позицию — сигнал сильный' }
    ];
    answers.forEach((a, i) => {
      const ay = 422 + i * 48;
      this.add.rectangle(14, ay, 362, 44, COLORS.surface).setStrokeStyle(1, COLORS.border).setOrigin(0)
        .setInteractive().on('pointerdown', () => this.handleAnswer(i));
      this.add.text(28, ay + 16, a.l, { ...FONT_MONO, fontSize: '11px', color: '#31D6C4' });
      this.add.text(60, ay + 16, a.t, { fontSize: '12px', color: '#E9F2FF', ...FONT_UI, wordWrap: { width: 300 } });
    });
  }
  private handleAnswer(index: number): void {
    const correct = 2;
    if (index === correct) this.cameras.main.flash(200, 59, 222, 138);
    else this.cameras.main.flash(200, 255, 89, 109);
    this.time.delayedCall(500, () => this.showReveal());
  }
  private showReveal(): void {
    const overlay = this.add.rectangle(0, 0, 390, 844, COLORS.bg, 0.9).setOrigin(0).setInteractive();
    this.add.circle(195, 350, 50, 0x060A12).setStrokeStyle(2, COLORS.crypto);
    this.add.text(195, 350, '?', { ...FONT_MONO, fontSize: '40px', color: '#B783FF' }).setOrigin(0.5);
    this.add.text(195, 420, 'Fake Breakout Phantom', { fontSize: '18px', color: '#E9F2FF', ...FONT_UI }).setOrigin(0.5);
    this.add.text(195, 445, 'СИЛУЭТ РАСКРЫТ · СТАДИЯ I', { ...FONT_MONO, fontSize: '10px', color: '#62708A' }).setOrigin(0.5);
    this.add.text(195, 520, '+24 XP  +6 COINS  ✓ РИСК', { ...FONT_MONO, fontSize: '14px', color: '#31D6C4' }).setOrigin(0.5);
    this.add.text(195, 580, 'Продолжить', { fontSize: '13px', color: '#31D6C4', ...FONT_UI }).setOrigin(0.5)
      .setInteractive().on('pointerdown', () => { overlay.destroy(); this.scene.restart(); });
  }
  private createBottomNav(): void {
    const items = [
      { label: 'ACADEMY', scene: 'AcademyScene' },
      { label: 'ARENA', scene: null },
      { label: 'COLLECTION', scene: 'CollectionScene' },
      { label: 'MORE', scene: null }
    ];
    items.forEach((item, i) => {
      const nx = i * (390 / 4);
      this.add.rectangle(nx, 784, 390 / 4, 60, COLORS.elevated).setStrokeStyle(1, COLORS.border).setOrigin(0)
        .setInteractive().on('pointerdown', () => { if (item.scene) this.scene.start(item.scene); });
      this.add.text(nx + 390 / 8, 814, item.label, { ...FONT_MONO, fontSize: '8px', color: i === 1 ? '#31D6C4' : '#62708A' }).setOrigin(0.5);
    });
  }
}
