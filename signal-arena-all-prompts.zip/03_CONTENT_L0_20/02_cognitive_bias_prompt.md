# PROMPT — Cognitive Bias Content Group

Add cognitive-bias learning only where it improves a real decision. Use market data + trader behavior + interpretation error + corrective action. Never use a bias label as the answer.

MVP focus: FOMO Wraith, Loss Aversion Wraith, Revenge Wraith, Paper-Hands Poltergeist, Dopamine Imp. Use Confirmation Bias Cult and Hubris Dragon only if prerequisites are met.

For each scenario provide observable trigger, temptation, harmful action, safer alternative, relevant Browser evidence, cards, enemy treatment and feedback. Avoid implying real trading profit.
