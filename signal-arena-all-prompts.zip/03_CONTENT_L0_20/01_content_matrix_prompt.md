# PROMPT — L0–20 Content Matrix

Create or audit the L0–20 content matrix. Use only approved chapter/enemy names. Do not write L21–99 content.

For each task specify: ID, level band, lesson, skills, objective, enemy, evolution stage, sources, question, 4 choices, correct choice, plausible wrong-choice logic, feedback, mastery effects, anti-memorization variations.

Requirements: authored tasks first, no random generation; 20–30 tasks; 25% safe/no-trade responses; 30% multi-skill; every lesson has 3 scenario patterns; every enemy return adds a new factor; theory precedes practice.

Return matrix, coverage gaps and next content package.
