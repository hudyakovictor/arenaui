# PROMPT — Scale Decision Gate

Do not generate L21–99 content until MVP evidence is supplied. Evaluate technical stability, first-path completion, browser comprehension, transfer-task result, D1 return intent, player perception of “this is a game”, safety and production capacity.

Output GO / ITERATE / STOP. If GO: divide L21–99 into four content packages, preserve chapter/enemy names, define new source unlocks, identify reusable task patterns and asset batches. If ITERATE: identify smallest core-loop changes. If STOP: identify failed assumption and alternatives.
