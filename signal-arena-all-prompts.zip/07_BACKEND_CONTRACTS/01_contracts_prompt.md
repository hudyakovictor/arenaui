# PROMPT — Frontend/Backend Contract Group

After the vertical slice works locally, define versioned schemas and shared runtime validation. Use TypeScript + Zod/JSON Schema/OpenAPI-compatible contracts. Do not connect real external market data yet.

Entities: player, lesson, skill, task, objective, enemy, trophy, source, sourcePayload, attempt, resolution, mastery, dailyWarmup, unlock, notification, tournamentEligibility.

Use stable IDs: lesson.levels_and_volume, skill.wait_for_confirmation, enemy.fake_breakout_phantom, task.ta.false_breakout.retest.v1, source.chart. UI text is localized separately from IDs.

Frontend sends taskId + selected option/skill only. Backend/rules are source of truth for correctness, XP, mastery, unlocks and trophies. Return schemas, versioning, error format, mock repository and contract-test plan.
