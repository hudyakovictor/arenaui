# PROMPT — Audio & Haptics Group

Create an audio/haptic specification, not final audio files. Define layered but restrained feedback: UI tap, source switch, skill select, correct, incorrect, unlock, enemy reveal, level up, ambience. Add volume controls and haptics toggle; all sound must be optional.

For each event: sound ID, purpose, emotional intensity, duration target, ducking rule, mobile haptic pattern, accessibility fallback and forbidden associations. Do not use casino/slot-machine reward language or manipulative urgency audio.
