# PROMPT — Motion & Feedback Group

Add motion only after static UI flow works. Motion must clarify state, reward correct learning behavior and preserve readability; never be decoration or hide timing.

Define centralized motion tokens: instant, fast, normal, slow, dramatic; standard/enter/exit/emphasis easing; reducedMotion alternative. Create motion specs for: source tab change, skill select, answer select, correct/incorrect feedback, XP update, skill unlock, enemy silhouette reveal, trophy evolution, level up, modal open/close.

For every motion: trigger, duration, easing, property, cancellation/reduced-motion behavior, sound/haptic hook, educational purpose. Avoid camera shake for normal incorrect answers and avoid gambling-like reward loops.
