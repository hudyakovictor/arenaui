# PROMPT — Future GameFi Scope (locked until Scale GO)

Explore only after validated core loop. Propose optional tournaments, cosmetics, premium analytics, B2B education, community and Web3 elements. Every proposal must pass: learning value, non-pay-to-win, regulatory/safety risk, implementation cost, onboarding cost, retention value and reversibility.

Do not make tokens, NFT, wallet, staking or payments prerequisites for learning. Tournament accuracy/quality must outrank speed.
