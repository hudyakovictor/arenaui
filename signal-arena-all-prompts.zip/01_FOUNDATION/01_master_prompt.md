# MASTER PROMPT — Signal Arena

Использовать как базовый контекст во всех последующих запросах.

Signal Arena — mobile-first web/mobile RPG-игра на Phaser 3/4, которая обучает анализу крипторынков, управлению риском и дисциплине от L0 до L99. Формула: 33% упрощённый терминал + 33% карточная игра + 33% Duolingo.

Игра должна обучать через активное применение, обратную связь, повторение и перенос навыка в новый контекст; она не гарантирует доход и не является реальным торговым сервисом.

Академия: теория → интерактивное усвоение → карта навыка.
Арена: ситуация/цель → встроенный Browser Widget → карты навыков → решение → feedback → mastery/XP/trophy.

В Browser Widget есть только релевантные источники: chart, news, on_chain, social_sentiment, order_book, funding_rates, economic_calendar. В задаче 1–7 вкладок, неактивные не отображать.

Карты/главы: Основы рынка и свечей; Уровни и объёмы; Индикаторы; Риск-менеджмент; Психология трейдинга; Новости и макро; Токеномика; Безопасность; Ончейн-анализ; Производные инструменты; Нарративы и сентимент; Дисциплина и рутина; Исполнение сделок; Математика трейдера; DeFi; Портфель и циклы; Торговая система.

Враги: Fake Breakout Phantom, Indicator Cult, Meme Mirage; Leverage Goblin, Liquidity Hydra, Stop-Hunt Kraken, Drawdown Leviathan; Headline Titan, Whale Syndicate, Correlation Spider; Rug Pull Phantom, Honeypot Mimic, Insider Syndicate, Unlock Titan, Token Parasite, Governance Golem; FOMO Wraith, Loss Aversion Wraith, Revenge Wraith, Paper-Hands Poltergeist, Narrative Siren, Dopamine Imp; Confirmation Bias Cult, Hubris Dragon.

Daily Warm-up — только `ArenaSessionMode=daily_warmup`, первый короткий encounter дня. Турниры — поздний режим проверки переноса; accuracy важнее скорости.

Стиль: dark cyber-finance RPG, controlled industrial/cyber atmosphere, navy-black surfaces, cyan/teal primary action, red only for risk/error, amber warning/reward. Не делать white SaaS, glassmorphism или TradingView clone.

При ответе всегда указывать: цель обучения, действие игрока, необходимые навыки, врага/ситуацию, источники, сложность, feedback, mobile UI, anti-guessing и что вынести в config.
