# PROMPT — Phaser Shell & Scene Architecture

Refactor/extend the attached Signal Arena Phaser project. Keep one index.html and one Phaser canvas. Main pages are Scenes; transient events are overlays, not pages.

Required scene groups:
- Bootstrap: Boot, Preload, Onboarding.
- Core: AcademyPath, AcademyLesson, Arena, Collection, More.
- Service: Profile, Notifications, Help, Marketplace, Settings.
- Future shell: TournamentLobby, TournamentEncounter.
- Dev-only: DesignSystem, UiGallery, TaskPreview, AssetPreview.

Required overlay types: feedback_success, feedback_failure, enemy_reveal, skill_unlock, level_up, source_intro, warmup_complete, pause, exit_confirm, theory_required, connection_error, loading.

Use folders: game, state, data, ui/tokens, ui/primitives, ui/navigation, ui/arena, ui/academy, ui/overlays, scenes, dev. Do not implement Web3/backend yet. Return build status, file tree, routes and known placeholders.
