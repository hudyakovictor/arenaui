# PROMPT — UI System Foundation

На основе Master Prompt создай/поддерживай Signal Arena Design System. Не создавай игровые страницы до утверждения компонентов.

Сделай/обнови: semantic tokens (colors, spacing, typography, radius, motion, touch target), UI primitives, game components, asset contracts, responsive rules и UI Gallery Scene.

Approved primitives: Surface, Button, IconButton, Chip, Badge, ProgressBar, Tabs, Modal, TopBar, BottomNav.
Approved game components: ArenaEncounterShell, MarketBrowserWidget, SourceTab, ChartPanel, NewsPanel, OrderBookPanel, SkillActionCard, SkillTray, EnemyThreatCard, AnswerOption, ArenaFeedbackPanel, AcademyLessonCard, TrophyCard, WarmupBanner.

Rules: raw hex/spacing/radius/font sizes outside tokens forbidden; touch targets >=44px; max 5 primary persistent bottom-nav items; Browser Widget required in Arena; Warm-up not navigation.

Create output: token file, component inventory, states, UI Gallery, asset contract, usage examples and compliance report.
