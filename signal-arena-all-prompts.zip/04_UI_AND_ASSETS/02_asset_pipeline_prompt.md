# PROMPT — Asset Pipeline Group

Prepare an asset production manifest, not final art. Group assets by MVP need: navigation/source SVG icons, UI symbols, 5–7 skill illustrations, 6 enemy master renders, chart/news/orderbook mock assets, FX placeholders.

Contracts: SVG master grid 24×24, one consistent line style; skill art transparent PNG/WEBP 1024×1024; enemy master transparent PNG/WEBP 1500×1500, 15% safe margin, usable as 1:1 / 4:5 / 16:9 / circular crop. Enemy variants: silhouette, reveal, active, defeated, evolved.

For each asset: ID, purpose, scene/component, format, dimensions, crop rule, priority, placeholder description, acceptance criteria. Do not create final style variants before UI components are approved.
