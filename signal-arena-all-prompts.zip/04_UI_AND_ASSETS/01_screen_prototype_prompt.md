# PROMPT — Screen Prototype Group

Create one approved screen prototype at a time from existing UI components. Before visual/code output provide: Screen ID, template, component inventory, tokens, asset slots, states, mobile composition, desktop adaptation and Compliance Gate.

Arena screens must contain Situation + Browser Widget + Skill Cards + Decision + Feedback zone. Academy screens must contain one concept + interaction + micro-check + reward path. Do not invent new components unless used in 3+ future places.

Output must state PASS/FAIL. If FAIL, fix before presenting final.
