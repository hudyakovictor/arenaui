# Screen Contract Template

Screen ID:
Purpose:
User moment:
Template:
Session mode:
Learning goal:
Required components:
States:
Assets:
Mobile layout:
Desktop adaptation:
Interactions:
Data keys:
Forbidden elements:
Compliance Gate:
- Game, not dashboard: PASS/FAIL
- Browser Widget if Arena: PASS/FAIL
- Relevant tabs only: PASS/FAIL
- Warm-up is not navigation: PASS/FAIL
- Situation→sources→skills→decision→feedback: PASS/FAIL
- Tokens/components only: PASS/FAIL
- Touch targets >=44px: PASS/FAIL
Status:
