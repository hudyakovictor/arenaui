# Component Contract Template

Component ID:
Purpose:
Used in at least 3 places:
Inputs/props:
States:
Events:
Token references:
Mobile constraints:
Desktop constraints:
Accessibility:
Asset slots:
Failure/empty/loading:
Screenshot cases:
Forbidden use:
Status:
