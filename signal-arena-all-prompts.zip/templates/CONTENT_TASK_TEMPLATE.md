# Arena Task Template

Task ID:
Schema version:
Level band / difficulty:
Learning objective:
Theory prerequisites:
Required skill cards:
Domain / enemy / stage:
Scenario setup:
Visible browser sources:
Source payloads:
Question:
A/B/C/D answers:
Correct answer:
Why each wrong answer is tempting:
Correct feedback:
Incorrect feedback:
XP/mastery/trophy effects:
Next recommendation:
Variation slots:
QA rejection checks:
