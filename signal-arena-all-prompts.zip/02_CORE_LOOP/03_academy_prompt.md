# PROMPT — Academy Group

Implement/refine only Academy. Each lesson must be compact and interactive: objective → 2–4 content blocks → visual/example placeholder → micro-check → skill unlock → CTA to a relevant Arena task.

Do not build long article pages or static course cards. Theory must create reusable skills and prepare multiple scenario combinations. If practice needs an unlearned skill, show TheoryRequired overlay with an explicit lesson CTA.

For each lesson provide: learning outcome, skill IDs, visual placeholders, micro-check, common misconception, unlock reward, Arena linkage and completion rule.
