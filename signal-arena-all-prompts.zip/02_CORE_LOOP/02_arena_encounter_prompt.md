# PROMPT — Arena Encounter Group

Implement/refine only the Arena encounter system. It must be a game encounter, not a dashboard.

Required order: briefing/situation → Browser Widget (only relevant tabs) → skill cards → answer selection → resolving → feedback → progress/recommendation.

Required states: loading, briefing, source_analysis, skill_selected, answer_selected, resolving, success, failure, review, retry, next. Use one Arena Scene and overlays where appropriate.

Task contract requires: id, levelBand, difficulty, objective, prerequisites, requiredSkills, enemyId/stage, visible sources, source payloads, 4 answers, correctAnswerId, per-option rationale, feedback, rewards, variation slots.

Before output: Browser present PASS/FAIL; 1–7 relevant sources PASS/FAIL; 4 answers PASS/FAIL; no answer leak PASS/FAIL; no Warm-up navigation PASS/FAIL.
