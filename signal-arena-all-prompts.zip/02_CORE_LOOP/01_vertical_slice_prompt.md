# PROMPT — Vertical Slice L0–20

Build one complete playable vertical slice. The goal is to validate the learning/game loop, not to expand feature count.

Flow:
Onboarding → Lesson → Skill unlock → guided Arena tutorial → Browser analysis → skill selection → 4 answer choices → success/failure feedback → enemy reveal/trophy → next lesson → mixed-skill encounter → next-day Daily Warm-up → Collection → theory gate.

Implement 5 lessons, 5–7 cards, 6 approved enemies, 20–30 authored tasks, 3 source types (Chart, News, Order Book), LocalStorage player progress. At least 25% of correct decisions must be wait/no-trade/reduce-risk/review. At least 30% tasks require 2+ skills.

Daily Warm-up is 3 prior-skill tasks inside Arena mode. Browser Widget is mandatory. Do not add real market feeds, real money, Web3, multiplayer or final art.

Output: playable flow, task list, state transitions, blockers, compliance audit.
