# Signal Arena — All Prompts Repository

Единый архив промптов и рабочих шаблонов для Signal Arena. Работать строго по числовому порядку папок. Не перескакивать к Web3, турнирам, финальному арту или L21–99, пока не подтверждён vertical slice L0–20.

## Порядок работы

1. `01_FOUNDATION` — неизменная концепция, UI system, Phaser shell.
2. `02_CORE_LOOP` — Academy → card → Arena → browser → decision → feedback.
3. `03_CONTENT_L0_20` — первые уроки, задачи, враги, источники, прогрессия.
4. `04_UI_AND_ASSETS` — сначала компоненты и asset contracts, потом экранные группы, затем финальные ассеты.
5. `05_MOTION_AUDIO` — motion/audio/haptics только после работающего статичного flow.
6. `06_QA_PLAYTEST` — build, UI regression, usability, learning transfer, MVP decision gate.
7. `07_BACKEND_CONTRACTS` — API/Zod/OpenAPI, сохранение, админский контентный pipeline.
8. `08_SCALE_L21_99` — масштабирование после GO по MVP.
9. `09_FUTURE_GAMEFI` — только после подтверждённого ядра.

## Главный принцип

Не генерировать экран, арт или код «с нуля». Для каждой работы использовать:

```text
Master Prompt → Group Prompt → Screen/Component Prompt → Compliance Check → Review
```

## Что считать группой

Группа — законченный набор связанных вещей, который можно проверить отдельно:

- один игровой flow;
- один набор reusable components;
- один домен/пакет контента;
- один пакет ассетов;
- один тип motion/audio feedback;
- один QA milestone.

Не делать все 17 уроков или 24 врага одной задачей. Делать пакетами, например L0–5, L6–10, L11–15, L16–20.

## Неизменные правила

- Phaser 3/4 — игровой движок; один `index.html`, игровые страницы = Phaser Scenes/overlays.
- Signal Arena — игра, не SaaS-dashboard, не лендинг, не обычный trading terminal.
- Арена всегда: ситуация → Browser Sources → Skill Cards → решение → feedback/progress.
- Browser Widget обязателен в Arena и показывает только релевантные 1–7 вкладок.
- Daily Warm-up — режим первой Arena-сессии дня, никогда не отдельная нижняя вкладка.
- Academy и Arena — главные разделы.
- Враги — обучающие архетипы; повтор = новый контекст/сложность.
- UI собирается из tokens + approved components; не использовать magic values.
- Никаких финансовых обещаний и поощрения чрезмерного риска.
- Web3/NFT/token/wallet не входят в MVP.

## Статусы работы

Для каждого результата добавить в конец:

```text
Status: DRAFT | READY_FOR_REVIEW | APPROVED | BLOCKED
Dependencies:
Open questions:
Next prompt:
```
