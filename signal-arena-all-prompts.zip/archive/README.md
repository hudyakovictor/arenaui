Move deprecated prompts here. Do not delete decisions: record why a prompt was replaced and link its successor.
