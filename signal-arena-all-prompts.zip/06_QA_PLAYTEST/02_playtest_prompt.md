# PROMPT — Learning Playtest Group

Design and analyse a 5–10 participant usability/learning test for the L0–20 vertical slice. Do not claim effectiveness without data.

Test: first-run comprehension, Academy→Arena transition, Browser Widget discovery, skill-card interpretation, answer reasoning, failure feedback, theory gate, next-day warm-up and a transfer task using a new scenario.

Capture: task completion, time, first-click, source opens, skill selection, answer changes, confidence, observed confusion, quotes, D1 intent. Define success thresholds, red flags, questions after each task and GO/ITERATE/STOP gate.
