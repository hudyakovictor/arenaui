# PROMPT — QA & Compliance Group

Audit the attached build against Signal Arena rules. Test mobile 360/390/412/480 and desktop 1024/1280/1440. Check scene navigation, browser visibility, daily warm-up placement, state transitions, save/load, overflow, touch targets, keyboard answers, reduced motion and placeholder failures.

Report: critical / high / medium / low issue; reproduction; expected vs actual; owner; smallest fix; regression test. Critical failures include: Arena without Browser Widget, Warm-up as navigation, dashboard drift, task without 4 choices, missing feedback, lost progress, answer leak.
