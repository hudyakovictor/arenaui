# Signal Arena Design System — Compact Contract

## Core

- Game identity: dark cyber-finance RPG, never SaaS/dashboard/landing page.
- Arena loop: Situation → Browser Sources → Skill Cards → Decision → Feedback.
- Academy and Arena are primary; Warm-up is only `Mode.daily_warmup`.
- Browser source tabs: 1–7, only relevant tabs visible.

## Tokens

All UI must use `SA.c`, `SA.s`, `SA.r`, `SA.z`, `SA.f` from `src/signalArena.ts`.
No raw colors, arbitrary spacing or new panel styles in scenes.

## Approved components

`Surface`, `Top`, `NavBar`, `BrowserWidget`, `Skills`, `Answers`, `OverlayManager`.
New components must have three future uses before becoming part of the system.

## Assets

- SVG icon masters: 24×24 line family.
- Skill illustrations: transparent PNG/WEBP, 1024×1024.
- Enemy masters: transparent PNG/WEBP, 1500×1500, 15% safe margin; must crop to square, portrait, banner and circular portrait.

## Compliance

Before accepting any new screen, verify:

- Game encounter, not site/dashboard.
- Browser widget present if Arena.
- Situation → source → cards → decision → feedback visible.
- Warm-up not shown in navigation.
- Mobile touch targets ≥44px.
- No answer leak through enemy art.
- Uses approved tokens/components.
