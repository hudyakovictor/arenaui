import Phaser from 'phaser';
import { ALL_SCENES } from './signalArena';
const p=new URLSearchParams(location.search); const start=p.get('scene')==='design-system'?'DesignSystem':'Boot';
const game=new Phaser.Game({type:Phaser.AUTO,parent:'game',width:390,height:844,backgroundColor:'#070B14',scene:ALL_SCENES,scale:{mode:Phaser.Scale.FIT,autoCenter:Phaser.Scale.CENTER_BOTH}});
game.scene.start(start);
