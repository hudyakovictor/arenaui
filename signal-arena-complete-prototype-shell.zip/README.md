# Signal Arena — Complete Prototype Shell v1.0

A single Phaser 3 + TypeScript + Vite archive with the complete **prototype shell**: player scenes, developer UI scenes, reusable primitives, placeholder content, navigation and modal infrastructure.

## Run

```bash
npm install
npm run dev
```

Open the Vite local URL. Open Design System directly with:

```text
?scene=design-system
```

## Main player scenes

- Preload and 3-step onboarding
- Academy Path and Academy Lesson
- Arena Encounter with mandatory embedded Browser Widget, Skill Cards and exactly 4 Answers
- Collection
- Theory Required
- More hub, Profile, Notifications, Help, Marketplace, Settings
- Tournament Lobby and Tournament Encounter

## Developer scenes

- UI Gallery: approved Surface states
- Design System: tokens, component/asset contracts and Arena rules

## Important product rules encoded

- One `index.html` is intentional: all pages are Phaser Scenes in one game canvas.
- Arena validates task data before rendering.
- Every Arena task has 1–7 relevant source tabs, skills and 4 answers.
- Warm-up is an Arena mode, never a navigation item.
- Browser widget is mandatory in Arena.
- Assets and backend are placeholders: replace later without changing scene architecture.

## Suggested next implementation

1. Split `src/signalArena.ts` into folders: `ui`, `scenes`, `overlays`, `data`, `state`.
2. Replace mock chart/news panels with real content renderers.
3. Add SVG icon atlas, enemy/skill image assets, sound and motion.
4. Connect Task/Player contracts to Fastify/Zod API.
5. Add Playwright screenshot testing for UI Gallery and encounter states.
